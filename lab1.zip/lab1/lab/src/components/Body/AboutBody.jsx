export default function AboutBody(){
    return(
        <>
        <div className="main">
        <div className="wrapper">
            <div className="book-house">
                <h3>About Us</h3>
                
                
                <img src="https://th.bing.com/th/id/OIP.odSm-Lqc9Au-acbkdUboowHaE-?rs=1&pid=ImgDetMain" />
                <p>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis at porttitor urna. className aptent taciti sociosqu 
                    ad litora torquent per conubia nostra, per inceptos himenaeos. Sed vitae libero nec felis rhoncus sollicitudin 
                    at non felis. Praesent posuere arcu sit amet augue viverra, feugiat tempus metus placerat. Aliquam iaculis mi 
                    at diam gravida venenatis. Suspendisse pretium ultricies libero, id congue nibh pretium ut. Sed condimentum nec
                     diam eget elementum. Donec sed purus congue, varius massa a, tristique ipsum. Maecenas ac nunc ipsum. Sed in
                      molestie nulla. Duis nisi nibh, pellentesque ac ultricies eget, lacinia vitae elit. Cras laoreet purus 
                      tellus. Vestibulum a condimentum felis, id euismod ligula.
                </p>
                <p>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis at porttitor urna. className aptent taciti sociosqu 
                    ad litora torquent per conubia nostra, per inceptos himenaeos. Sed vitae libero nec felis rhoncus sollicitudin 
                    at non felis. Praesent posuere arcu sit amet augue viverra, feugiat tempus metus placerat. Aliquam iaculis mi 
                    at diam gravida venenatis. Suspendisse pretium ultricies libero, id congue nibh pretium ut. Sed condimentum nec
                     diam eget elementum. Donec sed purus congue, varius massa a, tristique ipsum. Maecenas ac nunc ipsum. Sed in
                      molestie nulla. Duis nisi nibh, pellentesque ac ultricies eget, lacinia vitae elit. Cras laoreet purus 
                      tellus. Vestibulum a condimentum felis, id euismod ligula.
                </p>
            </div>
            
            
            </div>
        </div>
        </>
        
    )
}